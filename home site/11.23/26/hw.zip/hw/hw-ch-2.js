function logIn(mainString, searchString) {
    let position = 0;
    const occurrences = [];

    while (position !== -1) {
        position = mainString.indexOf(searchString, position);
        if (position !== -1) {
            occurrences.push(position);
            position += 1;
        }
    }

    return occurrences;
}

const stringToSearch = "бредуть бобри в сирі бори. бобри хоробрі, а для бобрят добрі";
const searchString = "ри";

const result = logIn(stringToSearch, searchString);
document.write("Positions of occurrences:", result);
